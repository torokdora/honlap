t = list(map(lambda x: list(map(int, x.split("-"))),open("input.txt").read().split("\n")))

l = list(filter( lambda x: x<9, t[0]))

print("2. feladat")
print(f'Az 1. sorban szereplő 9-nél kisebb számok maximuma: {max(l)}')

q = list(sorted(t[1]))[:15]
s = 1
for i in q:
    s *= i

print("3. feladat")
print(f' A  2. sorban szereplő 15 legkisebb szám szorzatának nagyságrendje: {len(str(s))}')

print("4. feladat")
print(f"A 3.sorban szereplő számok minimuma : {min(t[2])}")


t5 = list(map(lambda x: x**2,sorted(t[3])[-10:]))
print("5.feladat")
print(f"A 4.sorban szereplő 10 legnagyobb szám négyzeteinek összege: {sum(t5)}")

t6 = list(sorted(t[4]))[:12]
print("6.feladat")
print(f"Az 5.sorban szereplő 12 legkisebb szám összege: {sum(t6)} ")

from math import sqrt as gy
to = sum(t,[])
t7 = sorted(list(filter(lambda x: gy(x) == int(gy(x)), to)))
print("7.feladat")
print(f"Az inputban szereplő összes szám közül a négyzetszámok számtani közepe: {sum(t7)/len(t7):0.2f}")